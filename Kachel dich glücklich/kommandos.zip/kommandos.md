# i3 und Zusätze installieren (Debian)

sudo apt install i3-wm i3lock xss-lock dmenu network-manager-gnome
sudo apt install x11-utils rofi nitrogen numlockx arandr 

# Die i3 Config Datei

~/.config/i3/config

# Die i3 Webseite

https://i3wm.org/docs/

# Abstände und Rahmen

## Fensterabstände: 20 Pixel
gaps inner 20
gaps outer -10
## Kein Abstand im Vollbild
smart_gaps on
## Kein Rahmen im Vollbild
hide_edge_borders smart
## Keine Titelzeile
for_window [class="^.*"] border pixel 5

# Hintergrundbild

## Hintergrundbild-Auswahl starten
nitrogen

/usr/share/backgrounds

## Letzte Hintergrundbild-Auswahl wiederherstellen
nitrogen --restore &

# Ein Programm automatisch starten 

exec --no-startup-id "<Programm>"

## nitrogen automatisch starten
exec --no-startup-id nitrogen --restore

# Ein besserer Programm-Starter: rofi

bindcode $mod+40 exec "rofi -modi drun,run -show drun -show-icons true"

# Firefox mit Kürzel starten

bindsym $mod+b exec firefox

# Einfacher Programme schließen

bindsym $mod+q exec kill

# KI macht dir ein Farb-Thema

Mein Thema ist “Fröhlich”. Mach mir ein i3 Farbschema zu diesem Thema. Die Rahmen sollen 5 Pixel breit sein und keine Titelzeile haben.

# Finde Programm Namen

> xprop | grep WM_CLASS

# Den Taschenrechner immer Floating starten

for_window [class="gnome-calculator"] floating enable

## Debian Problem mit Rechner lösen:
> dconf write /org/gnome/calculator/refresh-interval 0

# Finde Tasten Codes

> xev | grep keycode

# Bspw Gimp mit Numpad-Null starten

bindsym $mod+KP_0 exec gimp

# Root Passwort-Abfrage erhalten

## Policykit installieren
sudo apt install policykit-1-gnome

## Policykit automatisch starten
exec --no-startup-id /usr/lib/policykit-1-gnome/polkit-gnome-authentication-agent-1 &



